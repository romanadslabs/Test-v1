<?php
// Set the recipient email for lead notifications
// TODO: change to your real inbox
$LEAD_RECIPIENT = 'leads@example.com';

